# FiveM Tools

    ******************   ***   ***                   ***   ***************         ******         ******          
	******************   ***    ***                 ***	   ***************         *** ***       *** ***  
	***							 ***               ***     ***					   ***  ***     ***  ***    
	***							  ***             ***	   ***					   ***   ***   ***   ***    
	*************		 ***       ***           ***       ***					   ***    *** ***    ***   
	*************        ***        ***         ***        ***************         ***     *****     ***  
	***					 ***         ***       ***         ***************         ***      ***      *** 
	***					 ***		  ***     ***          ***					   ***				 *** 	         
	***					 ***		   ***   ***    	   ***					   ***				 *** 	      
	***					 ***		    *** ***            ***					   ***				 *** 	      
	***					 ***		     *****             ***************         ***				 *** 	      
	***					 ***		      *** 			   ***************         ***				 *** 

**For the people who are having problems.**  

Discord : axel.gbn#0001

**What's the purpose of this?**

Program blocks the outbounding and inbounding calls from adhesive so they won't get to check your hwid from their auth server. Basically allows you to play FiveM on hwid banned computers.

**How to use:**
1. Supprimer mon cache FiveM
2. Supprimer DigitalEntitlements et CitizenFX
3. Lancer FiveM
4. Fermer le programme

**Current status**

Working


